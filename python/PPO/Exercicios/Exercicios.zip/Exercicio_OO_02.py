'''
2. Crie uma classe Lâmpada com os seguintes atributos e métodos:
Atributos:
1. Cor;
2. Voltagem;
3. Luminosidade;
4. Ligada (a lâmpada deve inicializar desligada).
Métodos:
1. Verificar se a lâmpada está ligada/desligada
2. Ligar/desligar a lâmpada.
Todos os atributos devem ser privados.
Crie um objeto da classe Lâmpada e teste os métodos criados.

'''
class Lampada:
    def __init__(self, cor, voltagem, luminosidade):
        self.__cor = cor
        self.__voltagem = voltagem
        self.__luminosidade = luminosidade
        self.__ligada = False  

    def verificar_estado(self):
        return "Ligada" if self.__ligada else "Desligada"

    def ligar(self):
        self.__ligada = True

    def desligar(self):
        self.__ligada = False


lampada = Lampada("Branca", 220, 800)


print(f"Estado inicial da lâmpada: {lampada.verificar_estado()}")
lampada.ligar()
print(f"Estado da lâmpada após ligar: {lampada.verificar_estado()}")
lampada.desligar()
print(f"Estado da lâmpada após desligar: {lampada.verificar_estado()}")
# %%
